myvalue=1
print(myvalue)
print(type(myvalue))